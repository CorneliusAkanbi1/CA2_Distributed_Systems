package com.example.demo;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadEmissions {

    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ca2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        try {
            // Parse XML file
            File xmlFile = new File("src/main/resources/emissions.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFile);

            // Initialize XPath
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();

            // Compile XPath expression
            XPathExpression expr = xpath.compile("//Row");

            // Execute XPath expression
            NodeList rows = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);

            // Connect to the database
            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                // Iterate through rows and insert into the database
                for (int i = 0; i < rows.getLength(); i++) {
                    Node row = rows.item(i);

                    // Extract values
                    String categoryValue = getNodeValue(row, "Category__1_3");
                    String yearValue = getNodeValue(row, "Year");
                    String scenarioValue = getNodeValue(row, "Scenario");
                    String gasUnitsValue = getNodeValue(row, "Gas___Units");
                    String valueValue = getNodeValue(row, "Value");

                    // Insert into the database
                    insertIntoDatabase(connection, categoryValue, yearValue, scenarioValue, gasUnitsValue, valueValue);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getNodeValue(Node row, String tagName) {
        NodeList nodes = row.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName().equals(tagName)) {
                return node.getTextContent();
            }
        }
        return "";
    }

    private static void insertIntoDatabase(Connection connection, String category, String year, String scenario, String gasUnits, String value) {
        try {
            // Check if any of the values are empty
            if (category.isEmpty() || year.isEmpty() || scenario.isEmpty() || gasUnits.isEmpty() || value.isEmpty()) {
                System.out.println("Skipping row with empty values.");
                return;
            }

            // SQL query to insert data into the emissions table
            String sql = "INSERT INTO emissions (category, year, scenario, gas_units, value) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                // Set parameters
                preparedStatement.setString(1, category);
                preparedStatement.setString(2, year);
                preparedStatement.setString(3, scenario);
                preparedStatement.setString(4, gasUnits);
                preparedStatement.setString(5, value);

                // Execute the update
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}


