package com.example.demo;

import java.util.List;

public interface UserService {

    User saveUser(User user);
    User findByUsername(String username);
    List<User> getAllUsers();
    User getUserById(Long id);
    User updateUser(Long id, User newUser);
    void deleteUser(Long id);
    User addUser(User user);
}
