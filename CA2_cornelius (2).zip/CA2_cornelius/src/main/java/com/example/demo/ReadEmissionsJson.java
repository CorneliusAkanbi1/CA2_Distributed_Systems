package com.example.demo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReadEmissionsJson {

    public static void main(String[] args) throws IOException {
        File jsonFile = new File("src/main/resources/GreenhouseGasEmissions2023.json");

        // Read the JSON file
        String jsonContent = new String(java.nio.file.Files.readAllBytes(jsonFile.toPath()));

        // Parse JSON
        JSONObject jsonObject = new JSONObject(jsonContent);
        JSONArray emissionsArray = jsonObject.getJSONArray("Emissions");

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/ca2";
        String username = "root";
        String password = "root";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Iterate through the JSON array and insert data into the database
            for (int i = 0; i < emissionsArray.length(); i++) {
                JSONObject emissionJson = emissionsArray.getJSONObject(i);

                // Extract data from JSON
                String category = emissionJson.getString("Category");
                String gasUnits = emissionJson.getString("Gas Units");
                double value = emissionJson.getDouble("Value");

                // Insert data into the database
                insertData(connection, category, gasUnits, value);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertData(Connection connection, String category, String gasUnits, double value) throws SQLException {
        // Define the SQL query
        String sql = "INSERT INTO emissions_json (category, gas_units, value) VALUES (?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Set parameters for the SQL query
            preparedStatement.setString(1, category);
            preparedStatement.setString(2, gasUnits);
            preparedStatement.setDouble(3, value);

            // Execute the SQL query
            preparedStatement.executeUpdate();
        }
    }
}
