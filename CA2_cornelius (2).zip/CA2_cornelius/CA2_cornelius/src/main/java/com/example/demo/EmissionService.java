package com.example.demo;

import java.util.List;

public interface EmissionService {

    List<Emission> getAllEmissions();
    Emission getEmissionById(Long id);
    List<Emission> getEmissionsByUser(User user);
    Emission saveEmission(Emission emission);
    void deleteEmission(Long id);
}
