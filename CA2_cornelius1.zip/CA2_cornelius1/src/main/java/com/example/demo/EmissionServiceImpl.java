package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.EmissionRepository;

import java.util.List;

@Service
public class EmissionServiceImpl implements EmissionService {

    @Autowired
    private EmissionRepository emissionRepository;

    @Override
    public List<Emission> getAllEmissions() {
        return emissionRepository.findAll();
    }

    @Override
    public Emission getEmissionById(Long id) {
        return emissionRepository.findById(id).orElse(null);
    }

    @Override
    public List<Emission> getEmissionsByUser(User user) {
        return null;
    }

    @Override
    public Emission saveEmission(Emission emission) {
        return emissionRepository.save(emission);
    }

    @Override
    public Emission updateEmission(Long id, Emission newEmission) {
        Emission existingEmission = emissionRepository.findById(id).orElse(null);
        if (existingEmission != null) {
            // Update fields as needed
            existingEmission.setCategory(newEmission.getCategory());
            existingEmission.setGasUnits(newEmission.getGasUnits());
            existingEmission.setValue(newEmission.getValue());
            return emissionRepository.save(existingEmission);
        } else {
            return null;
        }
    }

    @Override
    public void deleteEmission(Long id) {
        emissionRepository.deleteById(id);
    }

	@Override
	public Emission addEmission(Emission emission) {
		// TODO Auto-generated method stub
		return null;
	}
}

