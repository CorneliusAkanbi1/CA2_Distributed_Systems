package com.example.demo;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReadEmissions {

    public static void main(String argv[]) throws
            IOException, ParserConfigurationException, SAXException, SQLException {

        File xmlFile = new File("src/main/resources/emissions.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(xmlFile);

        System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

        NodeList rows = doc.getElementsByTagName("Row");

        // JDBC variables
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing a connection to the database
            String url = "jdbc:mysql://localhost:3306/ca2";
            String username = "root";
            String password = "root";
            connection = DriverManager.getConnection(url, username, password);

            // Prepared statement to insert data
            String sql = "INSERT INTO emissions (category, year, scenario, gas_units, value) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);

            int validEntriesCount = 0;

            for (int i = 0; i < rows.getLength(); i++) {
                Node row = rows.item(i);

                if (row.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) row;

                    // Get values from XML
                    String categoryValue = elem.getElementsByTagName("Category__1_3").item(0).getTextContent();
                    String yearValue = elem.getElementsByTagName("Year").item(0).getTextContent();
                    String scenarioValue = elem.getElementsByTagName("Scenario").item(0).getTextContent();
                    String gasUnitsValue = elem.getElementsByTagName("Gas___Units").item(0).getTextContent();
                    String valueContent = elem.getElementsByTagName("Value").item(0).getTextContent();

                    // Check conditions before inserting
                    if (isValidEntry(yearValue, scenarioValue, valueContent)) {
                        // Set values in the prepared statement
                        preparedStatement.setString(1, categoryValue);
                        preparedStatement.setString(2, yearValue);
                        preparedStatement.setString(3, scenarioValue);
                        preparedStatement.setString(4, gasUnitsValue);
                        preparedStatement.setString(5, valueContent);

                        // Execute the query
                        preparedStatement.executeUpdate();

                        validEntriesCount++;
                    }
                }
            }

            System.out.println("Total valid entries inserted into the database: " + validEntriesCount);

        } finally {
            // Close resources in the finally block
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    private static boolean isValidEntry(String year, String scenario, String value) {
        return "2023".equals(year) && "WEM".equals(scenario) && isNumeric(value) && Double.parseDouble(value) > 0;
    }

    private static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}


