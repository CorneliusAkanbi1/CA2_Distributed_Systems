package com.example.demo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/emissions")
public class EmissionController {

    @Autowired
    private EmissionService emissionService;

    @GetMapping
    public ResponseEntity<List<Emission>> getAllEmissions() {
        List<Emission> emissions = emissionService.getAllEmissions();
        return ResponseEntity.ok(emissions);
    }

    @GetMapping("/getMapping/{id}")
    public ResponseEntity<Emission> getEmissionById(@PathVariable Long id) {
        Emission emission = emissionService.getEmissionById(id);
        if (emission != null) {
        	return new ResponseEntity<>(emission, HttpStatus.OK);
        	} else {
        	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        	}
    }

    @PostMapping("/postMapping/")
    public ResponseEntity<Emission> addEmission(@RequestBody Emission emission) {
    Emission savedEmission = emissionService.addEmission(emission);
    return new ResponseEntity<>(savedEmission, HttpStatus.CREATED);
    }

    @PutMapping("/putMapping/")
    public ResponseEntity<Emission> updateEmission(@PathVariable Long id, @RequestBody Emission emission) {
    Emission updatedEmission = emissionService.updateEmission(id, emission);
    if (updatedEmission != null) {
    return new ResponseEntity<>(updatedEmission, HttpStatus.OK);
    } else {
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    }
    @DeleteMapping("/deleteMapping/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
    emissionService.deleteEmission(id);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
}
}
