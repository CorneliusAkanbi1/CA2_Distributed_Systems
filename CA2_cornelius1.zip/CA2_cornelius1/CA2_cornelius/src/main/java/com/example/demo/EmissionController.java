package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emissions")
public class EmissionController {

    @Autowired
    private EmissionService emissionService;

    @GetMapping
    public ResponseEntity<List<Emission>> getAllEmissions() {
        List<Emission> emissions = emissionService.getAllEmissions();
        return ResponseEntity.ok(emissions);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Emission> getEmissionById(@PathVariable Long id) {
        Emission emission = emissionService.getEmissionById(id);
        if (emission != null) {
            return ResponseEntity.ok(emission);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Emission> saveEmission(@RequestBody Emission emission) {
        Emission savedEmission = emissionService.saveEmission(emission);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedEmission);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmission(@PathVariable Long id) {
        emissionService.deleteEmission(id);
        return ResponseEntity.noContent().build();
    }

}
