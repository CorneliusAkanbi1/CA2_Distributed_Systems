package com.example.demo;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class ReadEmissions {

    public static void main(String argv[]) throws
            IOException, ParserConfigurationException, SAXException {

    	File xmlFile = new File("src/main/resources/emissions.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(xmlFile);

        System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

        NodeList rows = doc.getElementsByTagName("Row");

        for (int i = 0; i < rows.getLength(); i++) {

            Node row = rows.item(i);

            System.out.println("\nCurrent Element: " + row.getNodeName());

            if (row.getNodeType() == Node.ELEMENT_NODE) {

                Element elem = (Element) row;

                Node category = elem.getElementsByTagName("Category__1_3").item(0);
                String categoryValue = category.getTextContent();

                Node year = elem.getElementsByTagName("Year").item(0);
                String yearValue = year.getTextContent();

                Node scenario = elem.getElementsByTagName("Scenario").item(0);
                String scenarioValue = scenario.getTextContent();

                Node gasUnits = elem.getElementsByTagName("Gas___Units").item(0);
                String gasUnitsValue = gasUnits.getTextContent();

                Node value = elem.getElementsByTagName("Value").item(0);
                String valueValue = value.getTextContent();

                System.out.println("Category: " + categoryValue);
                System.out.println("Year: " + yearValue);
                System.out.println("Scenario: " + scenarioValue);
                System.out.println("Gas Units: " + gasUnitsValue);
                System.out.println("Value: " + valueValue);
            }
        }
    }
}

