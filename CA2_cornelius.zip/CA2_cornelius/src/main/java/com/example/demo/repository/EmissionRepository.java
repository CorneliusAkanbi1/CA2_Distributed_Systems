package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Emission;
import com.example.demo.User;

import java.util.List;

public interface EmissionRepository extends JpaRepository<Emission, Long> {

    List<Emission> findAllByUser(User user);
}
