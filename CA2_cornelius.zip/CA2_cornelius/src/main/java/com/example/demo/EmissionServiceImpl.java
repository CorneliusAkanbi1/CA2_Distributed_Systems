package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.EmissionRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EmissionServiceImpl implements EmissionService {

    @Autowired
    private EmissionRepository emissionRepository;

    @Override
    public List<Emission> getAllEmissions() {
        return emissionRepository.findAll();
    }

    @Override
    public Emission getEmissionById(Long id) {
        Optional<Emission> optionalEmission = emissionRepository.findById(id);
        return optionalEmission.orElse(null);
    }

    @Override
    public List<Emission> getEmissionsByUser(User user) {
        return emissionRepository.findAllByUser(user);
    }

    @Override
    public Emission saveEmission(Emission emission) {
        return emissionRepository.save(emission);
    }

    @Override
    public void deleteEmission(Long id) {
        emissionRepository.deleteById(id);
    }
}
